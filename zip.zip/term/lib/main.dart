import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:termproject/home_screen.dart';
import 'package:termproject/info/info_more_page.dart';
import 'package:termproject/info/info_page.dart';

import 'config/app_theme.dart';

void main() {
  runApp(GetMaterialApp(
    theme: AppTheme.light,
    //darkTheme: AppTheme.dark,
    home: HomeScreen(),
    getPages: [
      GetPage(name: '/info', page: () => InfoPage()),
      GetPage(
        name: '/infomore/:info',
        page: () => InfoMorePage(),
        transition: Transition.fade,
      ),
    ],
  ));
}
