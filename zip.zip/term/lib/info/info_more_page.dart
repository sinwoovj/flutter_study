import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:termproject/info/info_detail_page.dart';

class InfoMorePage extends StatefulWidget {
  const InfoMorePage({this.info, Key? key}) : super(key: key);
  final String? info;
  @override
  State<InfoMorePage> createState() => _InfoMorePageState();
}

class _InfoMorePageState extends State<InfoMorePage> {
  TextEditingController textEditingController = TextEditingController();
  @override
  void dispose() {
    textEditingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(widget.info.toString()),
              Text(Get.arguments.toString()),
              Text(Get.parameters['uid'].toString()),
              Text(Get.parameters['nickname'].toString()),
              ElevatedButton(
                  onPressed: () {
                    Get.back(result: textEditingController.text);
                  },
                  child: Text('끄기')),
              ElevatedButton(
                  onPressed: () {
                    Get.off(InfoDetailPage());
                  },
                  child: Text('디테일 페이지')),
              OutlinedButton(
                  onPressed: () {
                    Get.dialog(AlertDialog(
                      title: Text('다이얼로그'),
                      actions: [
                        TextButton(
                            onPressed: () {
                              Get.back();
                            },
                            child: Text('확인'))
                      ],
                    ));
                  },
                  child: Text('DIALOG')),
              SizedBox(
                height: 100,
                width: 300,
                child: TextField(
                  controller: textEditingController,
                  decoration: InputDecoration(hintText: '여기에 입력하셈'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
