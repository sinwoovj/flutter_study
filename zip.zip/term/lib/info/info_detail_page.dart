import 'package:flutter/material.dart';

class InfoDetailPage extends StatelessWidget {
  const InfoDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      backgroundColor: Colors.cyan,
    );
  }
}
