import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:termproject/info/info_more_page.dart';

class InfoPage extends StatefulWidget {
  const InfoPage({Key? key}) : super(key: key);

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> {
  TextEditingController textEditingController = TextEditingController();

  @override
  void dispose() {
    textEditingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                  onPressed: () async {
                    var result = await Get.toNamed('/infomore/abc?uid=abcde&nickname=songsong',
                        parameters: {'uid': 'abcde', 'nickname': 'songsong'},
                        arguments: textEditingController.text);
                    print('result : $result');
                  },
                  child: Text('이동')),
              SizedBox(
                width: 300,
                height: 100,
                child: TextField(
                  controller: textEditingController,
                  decoration: InputDecoration(hintText: '여기에 입력하셈'),
                ),
              ),
              TextButton(
                  onPressed: () {
                    Get.snackbar('title', 'message', snackPosition: SnackPosition.BOTTOM);
                  },
                  child: Text('스낵바')),
              TextButton(
                  onPressed: () {
                    Get.dialog(Dialog(
                        child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('1'),
                        Text('2'),
                        Text('3'),
                      ],
                    )));
                  },
                  child: Text('다이얼로그')),
              TextButton(
                  onPressed: () {
                    Get.bottomSheet(
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('1'),
                            Text('2'),
                            Text('3'),
                            Text('4'),
                            Text('5'),
                            Text('6'),
                          ],
                        ),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
                        backgroundColor: Colors.white);
                  },
                  child: Text('BOTTOM SHEET'))
            ],
          ),
        ],
      ),
    );
  }
}
